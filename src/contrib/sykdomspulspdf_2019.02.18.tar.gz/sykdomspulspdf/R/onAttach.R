.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: sykdomspulspdf")
  packageStartupMessage("Version 2019.02.18")
  packageStartupMessage("Developed by B Valcarcel")
  packageStartupMessage("Department of Infectious Disease Epidemiology and Modelling")
  packageStartupMessage("Norwegian Institute of Public Health")
}

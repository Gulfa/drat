.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: ui")
  packageStartupMessage("Version 2019.09.23 at 19:20")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

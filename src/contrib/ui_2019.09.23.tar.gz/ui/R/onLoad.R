.onLoad <- function(libname, pkgname) {
  fd::initialize(
    package = "ui",
    load_package = FALSE
  )
}

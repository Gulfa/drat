.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.06.24 at 15:47")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

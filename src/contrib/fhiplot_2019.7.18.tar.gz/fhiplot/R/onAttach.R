.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.07.18 at 12:19")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

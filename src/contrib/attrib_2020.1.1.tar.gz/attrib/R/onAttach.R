.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: attrib")
  packageStartupMessage("Version: 2020.01.01 at 14:51")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

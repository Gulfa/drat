## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(data.table)
library(ggplot2)

# Load raw data
d <- sykdomspuls::GenFakeDataRaw()
print(d)

## ------------------------------------------------------------------------
# Format the data into panel data
d <- sykdomspuls::FormatData(d,
    SYNDROME = "influensa",
    testIfHelligdagIndikatorFileIsOutdated = FALSE,
    removeMunicipsWithoutConsults = TRUE
  )
print(d)

## ------------------------------------------------------------------------
d <- d[age=="Totalt"]
print(d)

## ------------------------------------------------------------------------
setnames(d, "value", "n")
setnames(d, "consultWithInfluensa", "consult")
res <- sykdomspuls::QuasipoissonTrainPredictData(
  datasetTrain = d,
  datasetPredict = d,
  isDaily = F
)

print(res)


.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version 2019.04.24 at 04:48")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2020.02.20 at 08:58")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2020.01.14 at 08:29")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

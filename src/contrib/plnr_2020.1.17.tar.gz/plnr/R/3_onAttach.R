.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: plnr")
  packageStartupMessage("Version 2020.01.17 at 12:22")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: plnr")
  packageStartupMessage("Version 2020.04.03 at 15:50")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

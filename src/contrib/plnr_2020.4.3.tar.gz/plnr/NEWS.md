# plnr 2020.4.3

- set_opts function created, allowing for force_verbose to be set package wide

# plnr 2020.2.20

- create_rmarkdown skeleton created

# plnr 2020.1.28

- parallel_possible variable when initializing new Plan

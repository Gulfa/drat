.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: drathelper")
  packageStartupMessage("Version 2020.02.19 at 07:56")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

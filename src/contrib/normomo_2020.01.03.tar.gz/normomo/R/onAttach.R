.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2020.01.03 at 07:28")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

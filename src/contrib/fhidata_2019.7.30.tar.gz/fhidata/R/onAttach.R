.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.07.30 at 07:20")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

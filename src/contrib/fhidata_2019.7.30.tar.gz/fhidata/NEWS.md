# fhidata 2019.6.24

- Including childhood vaccination data.

# fhidata 2019.5.19

- Switching map files from UTM to lat/long coordinates.

# fhidata 2019.4.2

- Submission to CRAN.

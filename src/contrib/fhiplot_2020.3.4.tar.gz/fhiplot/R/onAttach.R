.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2020.03.04 at 09:37")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

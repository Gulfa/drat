.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: FHI")
  packageStartupMessage("Version $DATE")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

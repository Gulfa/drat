ipd_create_folders <- function(language, superfolder, yearOfInterest = NULL, seasonOfInterest = NULL) {
  folder_year_language <- path(
    type = "year",
    language = language,
    superfolder = superfolder,
    time = yearOfInterest
  )

  folder_season_language <- path(
    type = "season",
    language = language,
    superfolder = superfolder,
    time = seasonOfInterest
  )

  if (!is.null(yearOfInterest)) {
    fs::dir_create(file.path(folder_year_language), recurse = TRUE)

    fs::dir_create(file.path(folder_year_language, "Tables"))

    if (!superfolder %in% c("SHAREPOINT")) {
      fs::dir_create(file.path(
        folder_year_language,
        "Figures_serotype_funnel_singleyearlast"
      ))

      fs::dir_create(file.path(
        folder_year_language,
        "Figures_serotype_funnel_4yearbaseline"
      ))

      fs::dir_create(file.path(
        folder_year_language,
        "Figures_serotype_diversity"
      ))
    }

    fs::dir_create(file.path(
      folder_year_language,
      "Figures_incidence_vax"
    ))

    fs::dir_create(file.path(
      folder_year_language,
      "Figures_incidence_age"
    ))
  } else if (!is.null(seasonOfInterest)) {
    fs::dir_create(file.path(folder_season_language), recurse = TRUE)

    fs::dir_create(file.path(
      folder_season_language,
      "Figures_cumulative"
    ))

    if (!superfolder %in% c("SHAREPOINT")) {
      fs::dir_create(file.path(
        folder_season_language,
        "Figures_serotype_funnel_singleyearlast"
      ))

      fs::dir_create(file.path(
        folder_season_language,
        "Figures_serotype_funnel_4yearbaseline"
      ))
    }
  }
}

set_config <- function() {
  org::initialize_project(
    home = c(
      "G:/Helseregistre/MSIS/MSIS_UtenPersonid/autosurveillance/dofiles/",
      "/autosurveillance/dofiles/",
      tempdir()
    ),
    data = c(
      "G:/Helseregistre/MSIS/MSIS_UtenPersonid/autosurveillance/data/",
      "/data/",
      tempdir()
    ),
    folders_to_be_sourced = NULL,
    create_folders = TRUE
  )
}

men_get_pop <- function() {
  retval <- fhidata::norway_population_b2020[location_code == "norge", c("year", "pop", "age")]
  setnames(retval, "age", "xage")

  return(retval)
}

men_get_data <- function() {
  if (org::project$computer_id == 1) {
    channel <- RODBC::odbcDriverConnect(connection = "Driver={SQL Server};SERVER=dm-prod;DATABASE=MsisAnalyse;")
    masterData <- RODBC::sqlQuery(channel, "SELECT MeningokokkSubtype, Alder\u00C5r, Pr\u00F8vedato\u00C5r, Pr\u00F8vedatoM\u00E5ned FROM ViewNominativ WHERE Diagnose='Syst. meningokokksykdom';")
    RODBC::odbcClose(channel)

    saveRDS(masterData, file = sprintf("%s/meningococcal.RDS", org::project$data))

    names(masterData) <- c("Smstoff", "Alaar", "Paar", "Pmnd")

    # Smittestoff -> Smstoff
    # Alder\u00C5r -> Alaar
    # AlderM\u00E5neder -> Alm
    # Pr\u00F8vedato\u00C5r -> Paar
    # Pr\u00F8vedatoM\u00E5ned -> Pmnd
    # Pr\u00F8vedato -> Pdato

    masterData <- data.table(masterData)
  } else {
    masterData <- data.table(readRDS(file.path(
      org::project$data,
      "meningococcal.RDS"
    )))

    names(masterData) <- c("Smstoff", "Alaar", "Paar", "Pmnd")

    if (fhi::isoyear_n() > max(masterData$Paar)) {
      missingYears <- fhi::isoyear_n():(max(masterData$Paar) + 1)
      retval <- list()
      retval[[1]] <- masterData
      for (i in missingYears) {
        retval[[i]] <- masterData[Paar == max(masterData$Paar)]
        retval[[i]][, Paar := i]
      }
      masterData <- rbindlist(retval)
    }
  }


  masterData[, Smstoff := as.character(Smstoff)]
  # FixNorwegian(masterData,"Smstoff")
  for (i in 0:9) masterData[, Smstoff := gsub(i, "", Smstoff)]
  masterData[, Smstoff := trimws(Smstoff, which = "both")]
  masterData[Smstoff == "Neisseria meningitidis ina", Smstoff := "Nm ina"]
  masterData[is.na(Smstoff), Smstoff := "Nm ina"]
  masterData[Smstoff != "Nm ina", Smstoff := paste0("Nm ", Smstoff)]

  print(xtabs(~ masterData$Smstoff, addNA = T))

  return(masterData)
}

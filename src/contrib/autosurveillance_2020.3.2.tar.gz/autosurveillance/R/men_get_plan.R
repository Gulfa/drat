#' men_get_plan
#' @export
men_get_plan <- function(){
  set_config_men()

  org::set_results(c(
    "G:/Helseregistre/MSIS/MSIS_UtenPersonid/autosurveillance/results/meningococcal/",
    "/results/meningococcal/"
  ))

  p <- plnr::Plan$new()
  p$add_data(
    name = "master_data",
    fn = men_get_data
  )

  p$add_data(
    name = "master_pop",
    fn = men_get_pop
  )

  analyses <- expand.grid(
    superfolder = c("ALL_WITHOUT_TITLES","ALL_WITH_TITLES","SHAREPOINT"),
    language = c("NB","EN"),
    yearOfInterest = c(2015:lubridate::year(lubridate::today())),
    fn_name = c(
      "TableIncidenceByAgeAndSerotype",
      "FigureIncidenceByAgeAndSerotype_allages",
      "FigureIncidenceByAgeAndSerotype_16-19",
      "FigureSerotypeByYear_allages",
      "FigureSerotypeByYear_16-19",
      "TableIncidenceByAge",
      "TableIncidenceByMonth",
      "FigureIncidenceByMonth1Year",
      "FigureIncidenceByMonth1YearVs3"
    ),
    onlyShowTotal = as.logical(NA),
    stringsAsFactors = FALSE
  )
  setDT(analyses)

  # duplicating the analyses for onlyShowTotal=TRUE/FALSE
  temp1 <- analyses[fn_name %in% c(
    "FigureIncidenceByAgeAndSerotype_allages",
    "FigureIncidenceByAgeAndSerotype_16-19"
  )]
  temp2 <- copy(temp1)
  temp1[,onlyShowTotal:=TRUE]
  temp2[,onlyShowTotal:=FALSE]

  analyses <- analyses[!fn_name %in% c(
    "FigureIncidenceByAgeAndSerotype_allages",
    "FigureIncidenceByAgeAndSerotype_16-19"
  )]
  analyses <- rbind(
    analyses,
    temp1,
    temp2
    )

  # fixing age definitions
  analyses[,age_def := dplyr::case_when(
    fn_name == "FigureSerotypeByYear_allages" ~ "age_fig_serotype_by_year1",
    fn_name == "FigureSerotypeByYear_16-19" ~ "age_fig_serotype_by_year2",
  )]

  analyses[, use_title := TRUE]
  analyses[superfolder %in% c("ALL_WITHOUT_TITLES"), use_title:=FALSE]
  analyses[,name:=glue::glue(
    "{fn_name}_{superfolder}_{language}_{yearOfInterest}_{onlyShowTotal}",
    fn_name = fn_name,
    superfolder = superfolder,
    language = language,
    yearOfInterest = yearOfInterest,
    onlyShowTotal = onlyShowTotal
  )]

  # create filename
  analyses[,filename :=
    dplyr::case_when(
      fn_name == "TableIncidenceByAgeAndSerotype" ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Tables",
          "incidence_by_age_and_serotype.csv"
        ),

      fn_name == "FigureIncidenceByAgeAndSerotype_allages" & onlyShowTotal==FALSE ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Figures",
          paste0(language,"_incidence_by_age_serotype_all_ages.png")
        ),
      fn_name == "FigureIncidenceByAgeAndSerotype_16-19" & onlyShowTotal==FALSE ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Figures",
          paste0(language,"_incidence_by_age_serotype_16-19.png")
        ),
      fn_name == "FigureIncidenceByAgeAndSerotype_allages" & onlyShowTotal==TRUE ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Figures",
          paste0(language,"_incidence_by_age_all_ages.png")
        ),
      fn_name == "FigureIncidenceByAgeAndSerotype_16-19" & onlyShowTotal==TRUE ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Figures",
          paste0(language,"_incidence_by_age_16-19.png")
        ),

      fn_name == "FigureSerotypeByYear_allages" ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Figures",
          paste0(language,"_serotype_by_year_all_ages.png")
        ),
      fn_name == "FigureSerotypeByYear_16-19" ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Figures",
          paste0(language,"_serotype_by_year_16-19.png")
        ),

      fn_name == "TableIncidenceByAge" ~
        file.path(
          org::project$results_today,
          language,
          superfolder,
          yearOfInterest,
          "Tables",
          "incidence_by_age.csv"
        ),

      TRUE ~ "x"
    )
  ]

  p$add_analysis_from_df(df=analyses)
  names(p$analyses)[100:150]

  for(i in 1:nrow(analyses)){
    men_create_folders(
      language = analyses$language[i],
      superfolder = analyses$superfolder[i],
      yearOfInterest = analyses$yearOfInterest[i]
    )
  }

  ### end ###


  plan <- list()
  for(i in 1:nrow(analyses)){
    a <- analyses[i,]
    vaxDef <- config$ipd$vax_def_master
    vaxDefIncidenceAge <- config$ipd$vax_def_incidence_age_master
    if(a$language=="NB"){
      names(vaxDef)[names(vaxDef)=="NVT"] <- "Ikke-vaksine serotyper"
      vaxDefIncidenceAge[vaxDefIncidenceAge=="NVT"] <- "Ikke-vaksine serotyper"
    }

    seasonList <- unique(fhi::season(config$ipd$max_date-seq(1,3650,26)))

    for(seasonOfInterest in seasonList[1:3]){
      ipd_create_folders(
        language = a$language,
        superfolder = a$superfolder,
        seasonOfInterest=seasonOfInterest
      )

      folder <- path(
        type = "season",
        language = a$language,
        superfolder = a$superfolder,
        time = seasonOfInterest
      )

      ## funnel plot for serotypes
      if(a$superfolder != "SHAREPOINT"){
        for(age in config$ipd$age_list_funnel[[a$language]]){
          for(comparison in c("singleYearLast","4yearbaseline")){
            p$add_analysis(
              name = glue::glue("fig_funnel_season_{a$language}_{a$superfolder}_{seasonOfInterest}_{age}_{comparison}"),
              fn_name = "Figure_Funnel_Season",
              language = a$language,
              superfolder = a$superfolder,
              seasonOfInterest = seasonOfInterest,
              age = age,
              comparison = comparison,
              seasonList = seasonList,
              USE_TITLE=a$use_title,
              type = "season",
              time = seasonOfInterest,
              folder = folder
            )
            # Figure_Funnel_Season(
            #   rawSpecificNumbers,
            #   ageListFunnel,
            #   LANGUAGE=a$language,
            #   folder = folder,
            #   seasonOfInterest,
            #   seasonList,
            #   USE_TITLE=a$use_title
            # )
          }
        }
      }

      ## Figures_cumulative
      p$add_analysis(
        fn_name = "Figure_Cumulative",
        language = a$language,
        superfolder = a$superfolder,
        type = "season",
        time = seasonOfInterest,
        seasonOfInterest = seasonOfInterest,
        seasonList = seasonList,
        USE_TITLE=a$use_title,
        folder = folder
      )
      # Figure_Cumulative(
      #   rawGroupNumbers,
      #   ageListCumulative,
      #   seasonOfInterest,
      #   seasonList,
      #   LANGUAGE = a$language,
      #   folder = folder,
      #   USE_TITLE=a$use_title
      # )

    }

    ## TRUNCATING YEARS AS APPROPRIATE
    for(yearOfInterest in c(lubridate::year(config$ipd$max_date):(lubridate::year(config$ipd$max_date)-2))){
      ipd_create_folders(
        language = a$language,
        superfolder = a$superfolder,
        yearOfInterest=yearOfInterest
      )

      base_folder <- path(
        type = "year",
        language = a$language,
        superfolder = a$superfolder,
        time = yearOfInterest
      )

      ## Serotype specific table
      p$add_analysis(
        fn_name = "Table_Serotype",
        language = a$language,
        superfolder = a$superfolder,
        type = "season",
        time = seasonOfInterest,
        yearOfInterest = yearOfInterest,
        base_folder = base_folder
      )
      # Table_Serotype(
      #   rawSpecificNumbers,
      #   ageDef,
      #   yearOfInterest,
      #   base_folder = base_folder,
      #   LANGUAGE = a$language
      # )

      ## funnel plot for serotypes
      if(a$superfolder != "SHAREPOINT"){
        p$add_analysis(
          fn_name = "Figure_Funnel_Year",
          language = a$language,
          superfolder = a$superfolder,
          type = "season",
          time = seasonOfInterest,
          yearOfInterest = yearOfInterest,
          base_folder = base_folder,
          USE_TITLE = a$use_title
        )
        # Figure_Funnel_Year(
        #   rawSpecificNumbers,
        #   ageListFunnel,
        #   LANGUAGE = a$language,
        #   base_folder = base_folder,
        #   yearOfInterest,
        #   USE_TITLE = a$use_title
        # )

        # simpsons index
        p$add_analysis(
          fn_name = "Figure_Simpsons",
          language = a$language,
          superfolder = a$superfolder,
          type = "season",
          time = seasonOfInterest,
          yearOfInterest = yearOfInterest,
          base_folder = base_folder,
          USE_TITLE = a$use_title
        )
        # Figure_Simpsons(
        #   rawSpecificNumbers,
        #   ageListRestrictedAll,
        #   ageListSimpsons,
        #   DATA_CAPTION,
        #   yearOfInterest,
        #   base_folder = base_folder,
        #   LANGUAGE = a$language,
        #   USE_TITLE = a$use_title
        # )
      }

      ## Grouped table
      p$add_analysis(
        fn_name = "Table_Number_Incidence",
        language = a$language,
        superfolder = a$superfolder,
        type = "season",
        time = seasonOfInterest,
        yearOfInterest = yearOfInterest,
        base_folder = base_folder
      )
      # Table_Number_Incidence(
      #   correctedGroupNumbers,
      #   ageDef,
      #   yearOfInterest,
      #   LANGUAGE = a$language,
      #   base_folder = base_folder
      # )

      ## Figures_incidence_vax
      #correctedGroupNumbers[,age:=factor(age,levels=names(ageDef[[a$language]]))]

      p$add_analysis(
        fn_name = "Figure_Incidence_Vax",
        language = a$language,
        superfolder = a$superfolder,
        type = "season",
        time = seasonOfInterest,
        yearOfInterest = yearOfInterest,
        base_folder = base_folder,
        USE_TITLE=a$use_title
      )
      # Figure_Incidence_Vax(
      #   correctedGroupNumbers,
      #   ageListRestricted,
      #   yearOfInterest,
      #   LANGUAGE = a$language,
      #   base_folder = base_folder,
      #   USE_TITLE=a$use_title
      # )

      ## Figure_incidence_age
      p$add_analysis(
        fn_name = "Figure_Incidence_Age",
        language = a$language,
        superfolder = a$superfolder,
        type = "season",
        time = seasonOfInterest,
        yearOfInterest = yearOfInterest,
        base_folder = base_folder,
        vaxDefIncidenceAge=config$ipdvaxDefIncidenceAge,
        USE_TITLE=a$use_title
      )
      # Figure_Incidence_Age(
      #   correctedGroupNumbers,
      #   yearOfInterest,
      #   LANGUAGE = a$language,
      #   base_folder = base_folder,
      #   vaxDefIncidenceAge=vaxDefIncidenceAge,
      #   USE_TITLE=a$use_title
      # )
    }
  }

  return(p)
}

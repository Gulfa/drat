set_config_men <- function() {
  masterData <- men_get_data()

  config$men <- list()
  config$men$max_year <- max(masterData$Paar, na.rm = T)

  ageDef <- list(
    "NB" = list(
      "Alle aldersgrupper" = c(0:200),
      "0-4" = c(0:4),
      "5-15" = c(5:15),
      "16-19" = c(16:19),
      "20-39" = c(20:39),
      "40-59" = c(40:59),
      "60+" = c(60:200)
    ),
    "EN" = list(
      "All ages" = c(0:200),
      "0-4" = c(0:4),
      "5-15" = c(5:15),
      "16-19" = c(16:19),
      "20-39" = c(20:39),
      "40-59" = c(40:59),
      "60+" = c(60:200)
    )
  )

  serogroupDef <- list(
    "NB" = list(
      "Totalt" = unique(masterData$Smstoff)
    ),
    "EN" = list(
      "Total" = unique(masterData$Smstoff)
    )
  )
  for (i in unique(masterData$Smstoff)) {
    serogroupDef[["NB"]][[i]] <- i
    serogroupDef[["EN"]][[i]] <- i
  }

  tableAgesTableAgeAndSerotype <- list(
    "NB" = c("Alle aldersgrupper", "16-19"),
    "EN" = c("All ages", "16-19")
  )

  plotAgesFigure1 <- list(
    "NB" = c("Alle aldersgrupper"),
    "EN" = c("All ages")
  )

  plotAgesFigure2 <- list(
    "NB" = c("16-19"),
    "EN" = c("16-19")
  )

  plotAgesSerotypeByYear1 <- list(
    "NB" = c("Alle aldersgrupper"),
    "EN" = c("All ages")
  )

  plotAgesSerotypeByYear2 <- list(
    "NB" = c("16-19"),
    "EN" = c("16-19")
  )

  config$men$age <- ageDef
  config$men$serogroup <- serogroupDef
  config$men$age_table_age_and_serotype <- tableAgesTableAgeAndSerotype
  config$men$age_fig1 <- plotAgesFigure1
  config$men$age_fig2 <- plotAgesFigure2
  config$men$age_fig_serotype_by_year1 <- plotAgesSerotypeByYear1
  config$men$age_fig_serotype_by_year2 <- plotAgesSerotypeByYear2
}

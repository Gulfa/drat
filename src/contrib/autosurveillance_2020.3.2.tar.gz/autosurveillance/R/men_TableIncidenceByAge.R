men_DataCleaner_TableIncidenceByAge <- function(data, argset) {
  # data <- p$get_data()
  # argset <- p$get_argset("TableIncidenceByAge_ALL_WITH_TITLES_NB_2016_NA")

  d <- men_DataCleaner_Basic(data = data, argset = argset)

  d2 <- copy(d)
  d2[, year := 9999]
  d <- rbind(d, d2)

  # divide by 2 because we have total + specific serotypes
  d <- d[year <= argset$yearOfInterest | year == 9999, .(N = .N / 2), by = .(year, age)]

  skeleton <- data.table(expand.grid(
    year = c(min(d$year):argset$yearOfInterest, 9999),
    age = unique(d$age)
  ))
  d <- merge(skeleton, d, by = c("year", "age"), all.x = T)
  d[is.na(N), N := 0]
  return(d)
}

men_TableIncidenceByAge <- function(data, argset) {
  # data <- p$get_data()
  # argset <- p$get_argset("TableIncidenceByAge_ALL_WITH_TITLES_NB_2016_NA")

  d <- men_DataCleaner_TableIncidenceByAge(data = data, argset = argset)

  d[, year := formatC(year, digits = 0, format = "f", decimal.mark = ",")]
  d[year == "9999", year := "Total"]
  d[, N := formatC(N, digits = 0, format = "f", decimal.mark = ",")]
  d[, age := factor(age, levels = names(config$men$age[[argset$language]]))]
  d1 <- dcast.data.table(d, age ~ year, value.var = "N", fill = "0", drop = FALSE)

  d1 <- AddTitleToDF(d1, title = "Raw number of cases", copyColumnNames = TRUE)

  write.table(d1,
    file = arguments[["filename"]],
    row.names = F,
    col.names = F,
    sep = ";",
    dec = ",",
    qmethod = "double"
  )
}

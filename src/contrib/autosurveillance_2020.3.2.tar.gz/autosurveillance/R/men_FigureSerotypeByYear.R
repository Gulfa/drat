men_DataCleaner_FigureSerotypeByYear <- function(data, argset) {
  # data <- p$get_data()
  # argset <- p$get_argset("FigureSerotypeByYear_allages_ALL_WITH_TITLES_EN_2016_NA")

  d <- men_DataCleaner_Basic(data = data, argset = argset)

  d <- d[!serogroup %in% c("Total", "Totalt")]


  d <- d[age %in% config$men[[argset$age_def]][[argset$language]] &
    (year <= argset$yearOfInterest),
  .(N = .N),
  by = .(year, age, serogroup)
  ]

  skeleton <- data.table(expand.grid(
    year = c(min(d$year):argset$yearOfInterest),
    age = unique(d$age),
    serogroup = unique(d$serogroup)
  ))
  d <- merge(skeleton, d, by = c("year", "age", "serogroup"), all.x = T)
  d[is.na(N), N := 0]
  nrow(d)
  d[, totalN := sum(N), by = .(age, year)]
  d[, percentage := N / totalN * 100]
  d[, serogroup := gsub("Neisseria meningitidis", "Nm", serogroup)]

  seros <- unique(d$serogroup)
  seros <- seros[seros != "Nm ina"]
  seros <- c(seros, "Nm ina")
  d[, serogroup := factor(serogroup, levels = seros)]

  return(d)
}

men_FigureSerotypeByYear <- function(data, arguments = NULL) {
  # data <- p$get_data()
  # argset <- p$get_argset("FigureSerotypeByYear_allages_ALL_WITH_TITLES_EN_2016_NA")

  d <- men_DataCleaner_FigureSerotypeByYear(data = data, argset = argset)

  total <- list("NB" = "Totalt", "EN" = "Total")[[argset$language]]
  d[, prettyYear := sprintf("%s\n(n=%s)", year, totalN)]

  q <- ggplot(d, aes(x = prettyYear, y = percentage, fill = serogroup, group = serogroup))
  q <- q + geom_bar(lwd = 2, stat = "identity", alpha = 0.8)
  q <- q + scale_fill_brewer(list(
    "NB" = "Serogrupper",
    "EN" = "Serogroups"
  )[[argset$language]], palette = "Set2")
  q <- q + scale_x_discrete(
    list(
      "NB" = "\u00C5r",
      "EN" = "Year"
    )[[argset$language]]
  )
  q <- q + scale_y_continuous(arguments[["title_y"]])
  q <- q + labs(title = arguments[["title"]])
  q <- q + labs(caption = DATA_CAPTION[[arguments[["LANGUAGE"]]]])
  q <- q + theme_gray(base_size = THEME_BASE_SIZE)
  # q <- q + theme(legend.key.size = unit(10, "lines"))
  # q <- q + theme(axis.text.x = element_text(angle = 90, hjust = 0.5, vjust=0.5))
  saveA4(q,
    filename = arguments[["filename"]]
  )
}

men_DataCleaner_TableIncidenceByAgeAndSerotype <- function(data, argset = NULL) {
  # data <- p$get_data()
  # argset <- p$get_argset("TableIncidenceByAgeAndSerotype_ALL_WITHOUT_TITLES_NB_2015")

  d <- men_DataCleaner_Basic(data = data, argset = argset)

  pop <- men_clean_pop(data$master_pop, ageDef = config$men$age[[argset$language]])

  d2 <- copy(d)
  d2[, year := 9999]
  d <- rbind(d, d2)

  d <- d[
    age %in% config$men$age_table_age_and_serotype[[argset$language]] &
      (year <= argset$yearOfInterest | year == 9999),
    .(N = .N),
    by = .(year, age, serogroup)
  ]

  skeleton <- data.table(expand.grid(
    year = c(min(d$year):argset$yearOfInterest, 9999),
    age = unique(d$age),
    serogroup = unique(d$serogroup)
  ))
  d <- merge(skeleton, d, by = c("year", "age", "serogroup"), all.x = T)
  d[is.na(N), N := 0]
  nrow(d)
  d <- merge(d, pop, by = c("age", "year"), all.x = T)
  nrow(d)
  d[, totalN := sum(N) / 2, by = .(age, year)]
  d[, percentage := N / totalN * 100]
  d[, totalN := NULL]
  return(d)
}

TableIncidenceByAgeAndSerotype <- function(data, argset) {
  # data <- p$get_data()
  # argset <- p$get_argset("TableIncidenceByAgeAndSerotype_ALL_WITHOUT_TITLES_NB_2015")

  d <- men_DataCleaner_TableIncidenceByAgeAndSerotype(data = data, argset = argset)

  d[, incidence := formatC(N / pop * 100000, format = "f", decimal.mark = ",", digits = 1)]
  d[, percentage := formatC(percentage, format = "f", decimal.mark = ",", digits = 1)]
  d[, year := formatC(year, digits = 0, format = "f", decimal.mark = ",")]
  d[year == "9999", year := "Total"]
  d[, N := formatC(N, digits = 0, format = "f", decimal.mark = ",")]
  d[, age := factor(age, levels = config$men$age_table_age_and_serotype[[argset$language]])]
  d1 <- dcast.data.table(d, age + serogroup ~ year, value.var = "N", fill = "0", drop = FALSE)
  d2 <- dcast.data.table(d, age + serogroup ~ year, value.var = "percentage", fill = "0", drop = FALSE)
  d3 <- dcast.data.table(d, age + serogroup ~ year, value.var = "incidence", fill = "0", drop = FALSE)

  d1 <- cbind(
    AddTitleToDF(d1[age == config$men$age_table_age_and_serotype[[argset$language]][1]],
      title = "Raw number of cases", copyColumnNames = TRUE
    ),
    "", "",
    AddTitleToDF(d1[age == config$men$age_table_age_and_serotype[[argset$language]][2]],
      title = "Raw number of cases", copyColumnNames = TRUE
    )
  )

  d2 <- cbind(
    AddTitleToDF(d2[age == config$men$age_table_age_and_serotype[[argset$language]][1]],
      title = "Percentage", copyColumnNames = TRUE
    ),
    "", "",
    AddTitleToDF(d2[age == config$men$age_table_age_and_serotype[[argset$language]][2]],
      title = "Percentage", copyColumnNames = TRUE
    )
  )

  d3 <- cbind(
    AddTitleToDF(d3[age == config$men$age_table_age_and_serotype[[argset$language]][1]],
      title = "Incidence (per 100.000)", copyColumnNames = TRUE
    ),
    "", "",
    AddTitleToDF(d3[age == config$men$age_table_age_and_serotype[[argset$language]][2]],
      title = "Incidence (per 100.000)", copyColumnNames = TRUE
    )
  )

  retval <- rbind(d1, "", "", d2, "", "", d3, fill = T)
  for (i in which(names(retval) == "age")) retval[[i]] <- as.character(retval[[i]])
  retval[is.na(retval)] <- ""

  write.table(
    retval,
    file = argset$filename,
    row.names = F,
    col.names = F,
    sep = ";",
    dec = ",",
    qmethod = "double"
  )
}

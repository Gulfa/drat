## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
d <- spread::commuter(
  seiiar=spread::norway_seiiar_oslo_2017,
  commuters=spread::norway_commuters_2017,
  r0=1.8,
  latent_period = 1.9,
  infectious_period = 3.0,
  asymptomatic_prob=0,
  asymptomatic_relative_infectiousness=0,
  N=1,
  M=7*8
)

d

## ---- echo=FALSE, results='asis'-----------------------------------------
knitr::kable(head(mtcars, 10))


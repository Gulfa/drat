# noispiah 2018.10.25

## Migration

Migrating from [raubreywhite/dashboards_noispiah](https://www.github.com/raubreywhite/dashboards_noispiah/) to [folkehelseinstituttet/dashboards_noispiah](https://www.github.com/folkehelseinstituttet/dashboards_noispiah/)
.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2018.11.22 at 14:51")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

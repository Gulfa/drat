.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2020.03.05 at 13:01")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

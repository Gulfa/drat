# sykdomspuls 2018.10.12

## Migration

Migrating from [raubreywhite/dashboards_sykdomspuls](https://www.github.com/raubreywhite/dashboards_sykdomspuls/) to [folkehelseinstituttet/dashboards_sykdomspuls](https://www.github.com/folkehelseinstituttet/dashboards_sykdomspuls/)
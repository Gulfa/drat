#' Flags/values to be used in the 'dashboards' scene
#' @export config
config <- new.env()

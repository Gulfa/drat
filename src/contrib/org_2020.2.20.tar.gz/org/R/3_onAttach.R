.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: org")
  packageStartupMessage("Version 2020.02.20 at 11:29")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: smhb")
  packageStartupMessage("Version 2018.11.21 at 09:06")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

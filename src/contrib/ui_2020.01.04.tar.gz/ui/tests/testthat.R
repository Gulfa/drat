library(testthat)
library(ui)

test_check("ui")

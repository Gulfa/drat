.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: FHI")
  packageStartupMessage("Version 2019.10.01 at 10:22")
  packageStartupMessage("Developed by Richard White, B Valcarcel, Gunnar R\u00F8")
  packageStartupMessage("Department of Infectious Disease Epidemiology and Modelling")
  packageStartupMessage("Norwegian Institute of Public Health")
}

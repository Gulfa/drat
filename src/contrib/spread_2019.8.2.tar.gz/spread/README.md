# spread

An R package that contains different infectious disease spread models.

Currently we have implemented [commuter model](https://folkehelseinstituttet.github.io/spread/articles/commuter_model.html).
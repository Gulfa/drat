.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2019.10.07 at 15:59")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

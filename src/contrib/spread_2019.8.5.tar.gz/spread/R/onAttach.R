.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: spread")
  packageStartupMessage("Version: 2019.08.05 at 10:32")
  packageStartupMessage("Commuter model and C++ code developed by Solveig Engebretsen and Andreas Nyg\u00E5rd Osnes")
  packageStartupMessage("Ported to RCPP by Richard White")
}

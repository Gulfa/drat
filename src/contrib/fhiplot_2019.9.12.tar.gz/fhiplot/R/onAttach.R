.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.09.12 at 08:27")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

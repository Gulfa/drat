# sykdomspulspdf 2018.10.12

## Migration

Migrating from [raubreywhite/fhi](https://www.github.com/raubreywhite/dashboards_sykdomspulspdf/) to [folkehelseinstituttet/fhi](https://www.github.com/folkehelseinstituttet/dashboards_sykdomspulspdf/)

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2019.08.06 at 10:50")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

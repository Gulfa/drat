.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.06.14 at 06:28")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

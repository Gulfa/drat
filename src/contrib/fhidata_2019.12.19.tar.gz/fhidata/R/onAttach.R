.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.12.19 at 07:47")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

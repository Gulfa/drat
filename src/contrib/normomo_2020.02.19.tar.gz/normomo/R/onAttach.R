.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2020.02.19 at 13:30")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

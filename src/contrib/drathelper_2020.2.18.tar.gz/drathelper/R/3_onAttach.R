.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: drathelper")
  packageStartupMessage("Version 2020.02.18 at 15:45")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

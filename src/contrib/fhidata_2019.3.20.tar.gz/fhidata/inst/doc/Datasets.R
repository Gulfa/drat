## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
fhidata::get_data("norway_population", is_current_municips=TRUE)
fhidata::get_data("norway_population_current")

fhidata::get_data("norway_population", is_current_municips=FALSE)
fhidata::get_data("norway_population_original")

## ------------------------------------------------------------------------
fhidata::get_data("norway_population", is_current_municips=TRUE)
fhidata::get_data("norway_locations", is_current_municips=TRUE)
fhidata::get_data("norway_locations_long", is_current_municips=TRUE)
fhidata::get_data("norway_municip_merging")

## ------------------------------------------------------------------------
library(ggplot2)
library(data.table)

pd <- fhidata::get_data("norway_map_counties")

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=location_code), color="black")
q <- q + theme_void()
q <- q + coord_quickmap()
q


library(testthat)
library(org)

test_check("org")

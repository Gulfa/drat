.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: org")
  packageStartupMessage("Version 2020.02.27 at 04:52")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

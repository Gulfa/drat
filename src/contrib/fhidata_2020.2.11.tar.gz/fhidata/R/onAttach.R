.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2020.02.11 at 09:37")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

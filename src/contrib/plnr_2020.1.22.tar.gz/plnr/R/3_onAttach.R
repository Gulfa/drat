.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: plnr")
  packageStartupMessage("Version 2020.01.22 at 07:24")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

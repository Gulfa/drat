#' e_subject
#' @param subject a
#' @export
e_subject <- function(subject){
  if(!config$is_production){
    subject <- glue::glue("TEST: {subject}")
  }
  return(subject)
}

#' e_footer
#' @export
e_footer <- function(){
  return(glue::glue("
    DO NOT REPLY TO THIS EMAIL! This email address is not checked by anyone!
    <br>
    To add or remove people to/from this notification list, send their details to richard.white@fhi.no
    "))
}

#' e_emails
#' @param project a
#' @export
e_emails <- function(project){
  if(config$is_production){
    emails <- readxl::read_excel("/etc/gmailr/emails.xlsx")
  } else {
    emails <- readxl::read_excel("/etc/gmailr/emails_test.xlsx")
  }

  emails <- stats::na.omit(emails[[project]])

  return(emails)
}





.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2019.12.12 at 13:05")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

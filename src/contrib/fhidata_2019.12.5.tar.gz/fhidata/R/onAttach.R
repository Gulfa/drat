.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.12.05 at 18:45")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

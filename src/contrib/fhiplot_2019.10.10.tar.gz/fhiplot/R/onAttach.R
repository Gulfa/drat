.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.10.10 at 06:59")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

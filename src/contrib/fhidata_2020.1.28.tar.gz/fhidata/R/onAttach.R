.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2020.01.28 at 10:43")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

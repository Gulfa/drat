.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2019.09.19 at 11:28")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

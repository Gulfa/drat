

#' blah
#' @param yearweek a
#' @export
email_internal <- function(yearweek) {
  d <- fd::tbl("normomo_standard_results") %>%
    dplyr::filter(location_code == "norge") %>%
    dplyr::filter(age == "Total") %>%
    dplyr::collect() %>%
    fd::latin1_to_utf8()
  setorder(d, -wk)
  d <- d[1:10]

  tab <- huxtable::hux(
    "\u00C5r-uke" = d$yrwk,
    "Intet" = glue::glue("{round(d$thresholdp_0)} - {round(d$thresholdp_1)}"),
    "Lav" = glue::glue("{round(d$thresholdp_1)} - {round(d$thresholdp_2)}"),
    "H\u00F8y" = glue::glue(">{round(d$thresholdp_2)}"),
    "Reg." = d$nb,
    "Kor." = round(d$nbc),
    "Over." = round(d$excessp),
    "Z-score" = fhiplot::format_nor(d$zscore, 2)
  ) %>%
    huxtable::add_colnames() %>%
    fhiplot::huxtable_theme_fhi_basic() %>%
    huxtable::set_align(huxtable::everywhere, huxtable::everywhere, "center") %>%
    huxtable::set_top_padding(huxtable::everywhere, huxtable::everywhere, 0.1) %>%
    huxtable::set_bottom_padding(huxtable::everywhere, huxtable::everywhere, 0.1) %>%
    huxtable::set_left_padding(huxtable::everywhere, huxtable::everywhere, 0.1) %>%
    huxtable::set_right_padding(huxtable::everywhere, huxtable::everywhere, 0.1)

  huxtable::background_color(tab)[-1, 7] <- fhiplot::warning_color["low"]
  huxtable::background_color(tab)[which(d$status == "medium") + 1, 7] <- fhiplot::warning_color["med"]
  huxtable::background_color(tab)[which(d$status == "high") + 1, 7] <- fhiplot::warning_color["hig"]

  huxtable::background_color(tab)[which(d$status == "normal") + 1, 2] <- fhiplot::warning_color["low"]
  huxtable::background_color(tab)[which(d$status == "medium") + 1, 3] <- fhiplot::warning_color["med"]
  huxtable::background_color(tab)[which(d$status == "high") + 1, 4] <- fhiplot::warning_color["hig"]

  tab <- huxtable::add_rows(tab, tab[1, ], after = 0)

  tab <- huxtable::merge_cells(tab, 1, 2:4)
  tab[1, 2] <- "Overd\u00F8dlighet rekkevidder"

  tab <- huxtable::merge_cells(tab, 1, 5:7)
  tab[1, 5] <- "D\u00F8dsfall"

  tab[1, c(1, 8)] <- " "

  tab1_name <- "table1.png"
  tab1 <- fs::path(fhi::temp_dir(), tab1_name)
  fd::huxtable_to_png(tab, file = tab1)

  folders_normomo <- fs::dir_ls(fd::path("results", package = "normomo"))
  folders_normomo <- stringr::str_subset(folders_normomo, "[0-9][0-9][0-9][0-9]-[0-9][0-9]$")
  folder_normomo <- max(folders_normomo)
  yearweek_normomo <- stringr::str_extract(folder_normomo, "[0-9][0-9][0-9][0-9]-[0-9][0-9]$")

  img1_name <- glue::glue("incl_reported_norge-Total-{yearweek_normomo}.png")
  img1 <- fd::path(
    "results",
    yearweek_normomo,
    "graphs_status",
    img1_name,
    package = "normomo"
  )

  img2_name <- glue::glue("Status_tiles-{yearweek_normomo}.png")
  img2 <- fd::path(
    "results",
    yearweek_normomo,
    "graphs_status",
    img2_name,
    package = "normomo"
  )

  html <- glue::glue(
    "<html>",
    "Nye NorMOMO resultater er klare. ",
    "R{fhi::nb$aa}datene kommer fra D{fhi::nb$oe}ds{fhi::nb$aa}rsaksregisteret og vi analyserer det ved bruk av <a hrc='http://github.com/euromomonetwork/momo'>MOMO</a>. ",
    "Under kan du finne overd{fhi::nb$oe}delighet sammendraget til forrige uka.<br><br><br>",
    "<b>Tabell 1.</b> Z-score (antall standardavvik) og antall registrerte d{fhi::nb$oe}dsfall de 10 siste ukene.<br><br>",
    "<img src='cid:{tab1_name}' width='800' align='middle' style='display:block;width:100%;max-width:800px' alt=''><br><br>",
    "<b>Figur 1.</b> Totalt antall d{fhi::nb$oe}dsfall per uke det siste {fhi::nb$aa}ret ({fhi::nb$oe}verst) og de siste 5 {fhi::nb$aa}rene (nederst), alle aldersgrupper.<br><br>",
    "<img src='cid:{img1_name}' width='800' align='middle' style='display:block;width:100%;max-width:800px' alt=''><br><br>",
    "<b>Figur 2.</b> Totalt antall d{fhi::nb$oe}dsfall per uke det siste {fhi::nb$aa}ret fordelt p{fhi::nb$aa} fylke.<br><br>",
    "<img src='cid:{img2_name}' width='800' align='middle' style='display:block;width:100%;max-width:800px' alt=''><br><br>",
    "</html>"
  )

  fd::mailgun(
    subject = glue::glue("NorMOMO: Uke {yearweek_normomo} d{fhi::nb$oe}dlighet"),
    html = html,
    to = "dashboardsfhi@gmail.com",
    bcc = "riwh@fhi.no",
    inlines = c(tab1, img1, img2)
  )
}


#' blah
#' @param folderResultsYearWeek a
#' @param dateReliable a
#' @export
email_ssi <- function(folderResultsYearWeek, dateReliable) {
  currentYearWeek <- stringr::str_extract(folderResultsYearWeek, "[0-9]*-[0-9]*")

  files <- list.files(file.path(folderResultsYearWeek, "MOMO"))

  folderNorway1 <- files[stringr::str_detect(files, "norway")]
  files <- list.files(file.path(folderResultsYearWeek, "MOMO", folderNorway1))

  folderNorway2 <- files[stringr::str_detect(files, "COMPLETE")]
  files <- list.files(file.path(folderResultsYearWeek, "MOMO", folderNorway1, folderNorway2))

  attachFiles <- file.path(folderResultsYearWeek, "MOMO", folderNorway1, folderNorway2, files)

  reliableData <- file.path(tempdir(), files)
  x <- fread(attachFiles)
  x <- x[wk2 <= RAWmisc::YearWeek(dateReliable)]
  fwrite(x, reliableData)

  unstable <- ""
  if (CONFIG$WEEKS_UNRELIABLE > 1) {
    unstable <- sprintf("Please note that only data up to and including week %s is included, as data beyond this is not reliable.<br><br>", RAWmisc::YearWeek(dateReliable))
  }

  html <- glue::glue("
    Dear EuroMOMO hub,

    Please find attached the current week's results. {unstable}

    Sincerely,

    Norway
    ")

  fd::mailgun(
    subject = glue::glue("[euromomo input] [Norway] [{stringr::str_replace(currentYearWeek, '-', ' ')}]"),
    html = html,
    to = fd::e_emails("normomo_ssi"),
    attachments = reliableData
  )
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: ui")
  packageStartupMessage("Version 2019.09.26 at 08:50")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: FHI")
  packageStartupMessage("Version 2019.02.01 at 13:52")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version 2019.03.26 at 16:13")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

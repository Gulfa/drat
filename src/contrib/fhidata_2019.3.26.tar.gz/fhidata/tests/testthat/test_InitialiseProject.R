context("fhidata")

test_that("Create org::PROJ$SHARED_TODAY", {
  testthat::expect_equal(1, 1)
})

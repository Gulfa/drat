#' Flags/values to be used in the 'dashboards' scene
#' @export config
config <- new.env()

config$package <- "x"

config$name_computer <- "x"
config$name_production <- "smhb"
config$name_testing <- "smhb"

config$is_production <- FALSE
config$is_testing <- FALSE
config$is_dev <- FALSE

config$is_initialized <- FALSE

#' Environment to store logs
#' test
#' @export logdata
logdata <- new.env()
logdata$x <- 1

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fd")
  packageStartupMessage("Version: 2019.07.10 at 11:13")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2020.01.27 at 13:21")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

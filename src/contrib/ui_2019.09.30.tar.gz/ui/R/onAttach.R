.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: ui")
  packageStartupMessage("Version 2019.09.30 at 08:32")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

library(testthat)
library(attrib)

test_check("attrib")

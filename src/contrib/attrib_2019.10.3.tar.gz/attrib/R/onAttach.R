.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.10.03 at 12:41")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fd")
  packageStartupMessage("Version 2020.01.04 at 08:55")
}

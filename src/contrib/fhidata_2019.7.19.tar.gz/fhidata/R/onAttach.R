.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.07.19 at 09:42")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

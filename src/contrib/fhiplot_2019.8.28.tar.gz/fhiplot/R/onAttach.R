.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.08.28 at 14:52")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

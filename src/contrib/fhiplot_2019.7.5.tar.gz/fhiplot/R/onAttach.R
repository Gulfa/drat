.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.07.05 at 09:45")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.03.21 at 07:22")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

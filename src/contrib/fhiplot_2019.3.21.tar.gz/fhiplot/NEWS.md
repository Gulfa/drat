# org 2019.3.5

- Removal of stringr and lubridate dependencies

# org 2019.2.21

- Submission to CRAN
- Includes functions `AllowFileManipulationFromInitialiseProject` and `InitialiseProject`

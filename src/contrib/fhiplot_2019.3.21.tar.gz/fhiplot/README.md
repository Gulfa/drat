# fhiplot

This repo contains the functions of the `fhiplot` package, which once installed locally, provides helpful functions for creating and exporting graphics made in ggplot in the style used by the Norwegian Institute of Public Health.

# RAWmisc
[![Build Status](https://travis-ci.org/raubreywhite/RAWmisc.svg?branch=master)](https://travis-ci.org/raubreywhite/RAWmisc)
[![codecov](https://codecov.io/gh/raubreywhite/RAWmisc/branch/master/graph/badge.svg)](https://codecov.io/gh/raubreywhite/RAWmisc)

R Convenience functions

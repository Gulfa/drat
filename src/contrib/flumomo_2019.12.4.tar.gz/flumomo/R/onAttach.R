.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: attrib")
  packageStartupMessage("Version: 2019.12.04 at 12:36")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

library(testthat)
library(flumomo)

test_check("flumomo")

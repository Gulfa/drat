FHI epost
try to update from F mappe

sykehus

way forwards:
- you give me back 8/1/2019
- i change it before 1/3/2019
- kvalitetssikkre end of april

- end of may new data
- send out before reports 23. juni

- if denominator<5, then still keep x-axis, but delete results in graph/table

fd::initialize("brain")

suppressMessages(library(data.table))
suppressMessages(library(ggplot2))

install.packages("data.table", type = "source",
                 repos = "https://Rdatatable.gitlab.io/data.table")

weather_download$new()$run_all()

flumomo$new()$run_all()

# amort$new()$run_all()

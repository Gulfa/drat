fd::initialize("brain")

suppressMessages(library(data.table))
suppressMessages(library(ggplot2))

a <- weather_download$new()
a$run_all()

flumomo_run_all()

# amort$new()$run_all()

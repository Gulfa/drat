.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2020.01.03 at 19:04")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

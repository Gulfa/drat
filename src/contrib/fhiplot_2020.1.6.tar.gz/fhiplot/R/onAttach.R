.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2020.01.06 at 15:18")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

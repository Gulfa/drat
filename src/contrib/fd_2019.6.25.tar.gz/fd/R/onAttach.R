.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fd")
  packageStartupMessage("Version: 2019.06.25 at 09:02")
}

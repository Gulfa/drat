data_storage <- new.env()
data_storage$num_data <- 0

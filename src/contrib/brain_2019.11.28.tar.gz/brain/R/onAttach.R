.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2019.11.28 at 12:18")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

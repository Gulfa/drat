.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2019.08.01 at 10:29")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

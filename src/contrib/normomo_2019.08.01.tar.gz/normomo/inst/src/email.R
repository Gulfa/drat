
library(magrittr)
fd::mailgun(
  subject = "hello",
  to = "riwh@fhi.no",
  html
)
email <- emayili::envelope()

email <- email %>%
  emayili::from("dashboardsfhi@gmail.com") %>%
  emayili::to("riwh@fhi.no") %>%
  emayili::subject("This is a plain text message!") %>%
  emayili::body("<h1>Hello!</h1>{3+1}", type = "html")

fd::smtp(email)

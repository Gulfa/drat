

library(magrittr)

email <- emayili::envelope()

email <- email %>%
  emayili::from("dashboardsfhi@gmail.com") %>%
  emayili::to("riwh@fhi.no") %>%
  emayili::subject("This is a plain text message!") %>%
  emayili::body("<h1>Hello!</h1>{3+1}", type = "html")

# curl::send_mail(
#   mail_from="dashboardsfhi@gmail.com",
#   mail_rcpt="riwh@fhi.no",
#   smtp_server="smtp.gmail.com",
#   message=email,
#   username="dashboardsfhi@gmail.com",
#   password="fbyunhngvexjqlsm",
#   use_ssl=T
# )


fd::smtp(email, verbose=T)


IMmailgun

library(IMmailgun)
url <- "https://api.mailgun.net/v3/sandbox8c4c9441e2a747d8936803edef4a84f7.mailgun.org"
from <- "Mailgun Sandbox <postmaster@sandbox8c4c9441e2a747d8936803edef4a84f7.mailgun.org>"
api_key <- "eef863b3c1201a94b723144ddd425652-f877bd7a-f8af38c3"

httr::POST(
  url = paste0(url,"/messages"),
  httr::authenticate("api", api_key),
  encode = "multipart",
  body = list(
    from = from,
    to = "riwh@fhi.no",
    subject = "MULTIPART",
    html = "<h1>ok</h1>",
    attachment = httr::upload_file("/git/COURSES.txt"),
    attachment = httr::upload_file("/git/fd_2019.7.30.tar.gz")
  )
)

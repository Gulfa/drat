send_result <- processx::run("echo","hello")

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2020.02.26 at 08:17")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

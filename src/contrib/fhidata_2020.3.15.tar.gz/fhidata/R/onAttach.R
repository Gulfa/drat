.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2020.03.15 at 12:15")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

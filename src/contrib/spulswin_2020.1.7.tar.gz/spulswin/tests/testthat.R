library(testthat)
library(spulswin)

test_check("spulswin")

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("\nPACKAGE: spulswin")
  packageStartupMessage("Version: 2020.01.07 at 07:17")
  packageStartupMessage("\nIf you have any technical problems, please contact:")
  packageStartupMessage("- RichardAubrey.White@fhi.no")
  packageStartupMessage("- GunnarOyvindIsaksson.Ro@fhi.no")
  packageStartupMessage("\nIf you have any scientific questions, please contact:")
  packageStartupMessage("- GryMarysol.Groneng@fhi.no")
}

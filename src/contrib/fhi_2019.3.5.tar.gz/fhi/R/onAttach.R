.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: FHI")
  packageStartupMessage("Version 2019.03.05 at 18:50")
  packageStartupMessage("Developed by Richard White, B Valcarcel")
  packageStartupMessage("Department of Infectious Disease Epidemiology and Modelling")
  packageStartupMessage("Norwegian Institute of Public Health")
}

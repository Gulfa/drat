.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: attrib")
  packageStartupMessage("Version: 2019.10.04 at 09:56")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

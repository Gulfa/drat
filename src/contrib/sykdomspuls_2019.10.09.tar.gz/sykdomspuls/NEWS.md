# sykdomspuls 2018.11.23

## Available on Windows

- There is now documentation on how to install `sykdomspuls` on Windows

## Shiny App

- The shiny app is now available from inside `inst/shiny/sykdomspuls`
- The shiny app now reads data from a mysql database

# sykdomspuls 2018.10.12

## Migration

Migrating from [raubreywhite/dashboards_sykdomspuls](https://www.github.com/raubreywhite/dashboards_sykdomspuls/) to [folkehelseinstituttet/dashboards_sykdomspuls](https://www.github.com/folkehelseinstituttet/dashboards_sykdomspuls/)

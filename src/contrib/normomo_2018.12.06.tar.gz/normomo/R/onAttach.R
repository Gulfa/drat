.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2018.12.06 at 09:42")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

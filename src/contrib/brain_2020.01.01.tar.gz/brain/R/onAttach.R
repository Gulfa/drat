.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2020.01.01 at 17:49")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

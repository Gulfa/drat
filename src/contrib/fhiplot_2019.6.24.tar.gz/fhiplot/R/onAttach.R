.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.06.24 at 08:58")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.06.24 at 09:53")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

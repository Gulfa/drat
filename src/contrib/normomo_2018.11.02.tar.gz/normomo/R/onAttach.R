.onAttach <- function(libname, pkgname) {
  packageStartupMessage('PACKAGE: normomo')
  packageStartupMessage('Version')
  packageStartupMessage('Developed by Richard White, Norwegian Institute of Public Health')
}

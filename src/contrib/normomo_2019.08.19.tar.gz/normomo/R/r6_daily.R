#' quasipoission
#' @import R6
#' @export daily
daily <- R6::R6Class(
  "daily",
  portable = FALSE,
  cloneable = FALSE,
  list(
    results_x = NULL,
    initialize = function() {
      results_x <<- fd::schema$new(
        db_config = CONFIG$db_config,
        db_table = glue::glue("normomo_daily_results"),
        db_field_types = daily_results_field_types,
        db_load_folder = "/xtmp/",
        keys = daily_results_keys,
        check_fields_match = TRUE
      )

      results_x$db_connect()
    },
    run_all = function(masterData) {
      conn <- fd::get_db_connection()
      fd::use_db(conn, "sykdomspuls")
      weekly <- dplyr::tbl(conn, "normomo_standard_results") %>%
        dplyr::collect() %>%
        fd::latin1_to_utf8()
      weekly <- weekly[,c("location_code","age","yrwk","nb","nbc")]
      setnames(weekly,c("nb","nbc"),c("weekly_nb","weekly_nbc"))

      d <- masterData[,.(nb=.N),keyby=.(ageCat,DoD)]
      dt <- d[,.(nb=sum(nb)),keyby=.(DoD)]
      dt[,ageCat:="Total"]
      d <- rbind(d,dt)
      d[,age:=car::recode(as.character(ageCat), "'[0,4]'='0to4';'(4,14]'='5to14';'(14,64]'='15to64';'(64,200]'='65P'")]
      d[,ageCat:=NULL]

      skeleton <- expand.grid(
        DoD=seq.Date(min(d$DoD),max(d$DoD),1),
        age=unique(d$age),
        stringsAsFactors = F
        )
      setDT(skeleton)
      skeleton[d,on=c("DoD","age"),nb:=nb]
      skeleton[is.na(nb), nb:=0]
      skeleton[,yrwk:=fhi::isoyearweek(DoD)]
      skeleton[weekly,on=c("yrwk","age"),weekly_nb:=weekly_nb]
      skeleton[weekly,on=c("yrwk","age"),weekly_nbc:=weekly_nbc]
      skeleton[,day_of_week:=lubridate::wday(DoD)]
      skeleton[,needs_correction:=abs(weekly_nb-weekly_nbc)>10]
      proportions <- skeleton[needs_correction==F,.(prop=mean(nb/weekly_nbc,na.rm=T)),keyby=.(age,day_of_week)]
      skeleton[proportions,on=c("day_of_week","age"),prop:=prop]
      skeleton[,nbc:=nb]
      skeleton[needs_correction==T,nbc:=round(prop*weekly_nbc)]
      skeleton <- skeleton[,c("DoD","age","nb","nbc")]
      skeleton[,location_code:="norway"]
      setnames(skeleton,"DoD","date")

      results_x$db_upsert_load_data_infile(skeleton)

    }
  )
)

daily_results_field_types <- c(
  "location_code" = "TEXT",
  "age" = "TEXT",
  "date" = "DATE",
  "nb" = "DOUBLE",
  "nbc" = "DOUBLE"
)

daily_results_keys <- c(
  "location_code",
  "age",
  "date"
)

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2019.10.04 at 10:11")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2020.01.28 at 09:59")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2020.01.28 at 10:53")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

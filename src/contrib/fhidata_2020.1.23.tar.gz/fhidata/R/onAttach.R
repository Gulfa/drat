.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2020.01.23 at 14:36")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

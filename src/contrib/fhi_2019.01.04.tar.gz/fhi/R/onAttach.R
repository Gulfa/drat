.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: FHI")
  packageStartupMessage("Version 2019.01.04 at 07:29")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

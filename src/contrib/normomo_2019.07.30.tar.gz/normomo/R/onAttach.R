.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2019.07.30 at 10:22")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

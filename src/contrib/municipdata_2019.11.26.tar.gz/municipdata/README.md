# MunicipalityDataNorway

Here I have gathered municipality data from Statistics Norway Statistical Bank.

I have the datasets in the following order

1. Sociodemographics.
2. 
3. User charges


cb stands for codebook!
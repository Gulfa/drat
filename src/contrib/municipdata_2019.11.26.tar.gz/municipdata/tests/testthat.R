library(testthat)
library(municipdata)

test_check("municipdata")

# municipdata 2019.11.26

- Initial creation

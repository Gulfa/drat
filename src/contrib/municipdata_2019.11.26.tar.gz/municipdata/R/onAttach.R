#' @import data.table
.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: municipdata")
  packageStartupMessage("Version: 2019.11.26 at 06:51")
  packageStartupMessage("Developed by Henning \u00D8ien, Norwegian Institute of Public Health")
}

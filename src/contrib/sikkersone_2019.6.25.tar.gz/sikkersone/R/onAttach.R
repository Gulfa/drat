.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: sikkersone")
  packageStartupMessage("Version: 2019.06.25 at 06:30")
}

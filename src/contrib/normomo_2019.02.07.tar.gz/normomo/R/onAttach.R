.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2019.02.07 at 13:41")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

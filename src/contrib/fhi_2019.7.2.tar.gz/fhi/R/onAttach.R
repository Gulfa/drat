.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: FHI")
  packageStartupMessage("Version 2019.07.02 at 07:44")
  packageStartupMessage("Developed by Richard White, B Valcarcel")
  packageStartupMessage("Department of Infectious Disease Epidemiology and Modelling")
  packageStartupMessage("Norwegian Institute of Public Health")
}

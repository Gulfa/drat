.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fd")
  packageStartupMessage("Version: 2019.08.03 at 14:44")
}

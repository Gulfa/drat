.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2019.11.22 at 07:36")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: attrib")
  packageStartupMessage("Version: 2019.10.24 at 10:19")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2020.01.04 at 09:55")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

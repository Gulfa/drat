.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.12.04 at 10:22")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

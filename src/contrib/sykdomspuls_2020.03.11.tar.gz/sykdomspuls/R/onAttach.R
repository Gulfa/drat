.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: sykdomspuls")
  packageStartupMessage("Version 2020.03.11 at 15:30")
  packageStartupMessage("Developed by Richard White, Gunnar Ro")
  packageStartupMessage("Department of Infectious Disease Epidemiology and Modelling")
  packageStartupMessage("Norwegian Institute of Public Health")
  packageStartupMessage("https://folkehelseinstituttet.github.io/dashboards_sykdomspuls/\n")
}

#!/bin/bash

echo "hi"
library(testthat)
library(HRHRpal)

test_check("HRHRpal")

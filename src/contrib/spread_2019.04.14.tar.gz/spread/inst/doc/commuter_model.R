## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
d <- spread::commuter(
  pop_wo_com=spread::norway_pop_wo_com_2017,
  di_edge_list=spread::norway_di_edge_list_2017,
  start_points=spread::start_points_oslo,
  r0=1.8,
  beta=NULL,
  a=1/1.9,
  gamma=1/3,
  asymptomatic_prob=0,
  asymptomatic_relative_infectiousness=0,
  N=1,
  M=7*8
)

d

## ---- echo=FALSE, results='asis'-----------------------------------------
knitr::kable(head(mtcars, 10))


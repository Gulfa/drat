.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2019.11.29 at 05:33")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2019.12.05 at 18:47")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

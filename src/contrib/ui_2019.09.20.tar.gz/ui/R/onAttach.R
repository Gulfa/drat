.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: ui")
  packageStartupMessage("Version 2019.09.20 at 12:14")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

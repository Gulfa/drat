.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: org")
  packageStartupMessage("Version 2019.03.08 at 10:07")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

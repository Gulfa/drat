.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: ui")
  packageStartupMessage("Version 2019.09.25 at 04:53")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

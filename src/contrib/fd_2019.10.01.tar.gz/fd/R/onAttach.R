.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fd")
  packageStartupMessage("Version 2019.10.01 at 09:50")
}

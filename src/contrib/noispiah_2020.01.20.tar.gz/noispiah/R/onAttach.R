.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: noispiah")
  packageStartupMessage("Version 2020.01.20 at 18:34")
  packageStartupMessage("Developed by Richard White")
  packageStartupMessage("Department of Infectious Disease Epidemiology and Modelling")
  packageStartupMessage("Norwegian Institute of Public Health")
}

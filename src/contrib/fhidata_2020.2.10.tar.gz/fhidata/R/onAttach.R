.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2020.02.10 at 20:53")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

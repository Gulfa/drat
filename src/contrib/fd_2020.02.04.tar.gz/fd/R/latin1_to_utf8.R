#' latin1_to_utf8
#' Takes a data.frame and converts it to utf8
#' @param df data.frame to convert
#' @export
latin1_to_utf8 <- function(df) {
  setDT(df)
  for (i in names(df)) {
    try(if ("UTF-8" %in% Encoding(df[[i]])) df[, (i) := iconv(get(i), from = "latin1", to = "utf8")], TRUE)
  }

  if ("location_name" %in% names(df)) {
    bad_name <- glue::glue("M{fhi::nb$oe}re-og-Romsdal")
    good_name <- glue::glue("M{fhi::nb$oe}re og Romsdal")
    df[location_name == bad_name, location_name := good_name]
  }
  if ("location_name" %in% names(df) & "location_code" %in% names(df)) {
    df[location_code == "municip3040", location_name := "Nesbyen"]
  }
  return(df)
}

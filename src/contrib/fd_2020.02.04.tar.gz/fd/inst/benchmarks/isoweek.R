microbenchmark::microbenchmark(
  lubridate::isoweek("2019-01-01"),
  data.table::isoweek("2019-01-01"),
  format.Date("2019-01-01", "%V"),
  ISOweek::ISOweek("2019-01-01"),
  times = 100
)

microbenchmark::microbenchmark(
  lubridate::isoyear("2019-01-01"),
  format.Date("2019-01-01", "%G"),
  times = 100
)


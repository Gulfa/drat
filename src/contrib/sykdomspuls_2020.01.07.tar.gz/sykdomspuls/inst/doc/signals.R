## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(sykdomspuls)
library(data.table)
library(ggplot2)

# Load raw data
d <- GenFakeDataRaw()
print(d)

## ------------------------------------------------------------------------
# Format the data into panel data
d <- CleanData(d,
    syndrome = "influensa",
    testIfHelligdagIndikatorFileIsOutdated = FALSE,
    removeMunicipsWithoutConsults = TRUE
  )
print(d)

## ------------------------------------------------------------------------
d <- d[age=="Totalt" & granularity_geo=="municip"]
print(d)

## ------------------------------------------------------------------------
res <- sykdomspuls::QuasipoissonTrainPredictData(
  datasetTrain = d,
  datasetPredict = d,
  isDaily = F
)

print(res)


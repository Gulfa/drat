# test
# assign("norwayLocations", readxl::read_excel("data_structural/norwayLocations.xlsx"), envir=globalenv())

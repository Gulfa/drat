.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: plnr")
  packageStartupMessage("Version 2020.02.21 at 08:22")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

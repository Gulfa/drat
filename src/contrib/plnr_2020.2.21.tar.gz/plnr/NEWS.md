# plnr 2020.2.20

- create_rmarkdown skeleton created

# plnr 2020.1.28

- parallel_possible variable when initializing new Plan

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: FHI")
  packageStartupMessage("Version 2019.02.03 at 13:03")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: plnr")
  packageStartupMessage("Version 2020.01.21 at 17:11")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

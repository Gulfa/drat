## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(ggplot2)
library(fhiplot)

## ------------------------------------------------------------------------
fhiplot::Display_All_Palettes()

## ------------------------------------------------------------------------
ggplot(iris, aes(Sepal.Width, Sepal.Length, color = Species)) +
    geom_point(size = 4) +
    theme_classic()+
    fhiplot::scale_color_fhi(palette = "dis_primary")

ggplot(iris, aes(Sepal.Width, Sepal.Length, color = Species)) +
    geom_point(size = 4) +
    fhiplot::scale_color_fhi(palette = "dis_primary")


## ------------------------------------------------------------------------
ggplot(diamonds, aes(x=color, fill = cut)) +
  theme_classic()+
  geom_bar() +
  fhiplot::scale_fill_fhi(palette = "dis_primary")

ggplot(diamonds, aes(x=color, fill = cut)) +
  geom_bar() +
  fhiplot::scale_fill_fhi(palette = "dis_primary")


## ------------------------------------------------------------------------
ggplot(diamonds, aes(x=color, fill = cut)) +
  theme_classic()+
  geom_bar() +
  fhiplot::scale_fill_fhi(palette = "div_blue_red", direction = -1)

ggplot(diamonds, aes(x=color, fill = cut)) +
  geom_bar() +
  fhiplot::scale_fill_fhi(palette = "div_blue_red", direction = -1)


## ------------------------------------------------------------------------
ggplot(diamonds, aes(x=color, fill = cut)) +
  theme_classic()+
  geom_bar(alpha=0.7) +
  fhiplot::scale_fill_fhi(palette = "div_blue_red", direction = -1)

ggplot(diamonds, aes(x=color, fill = cut)) +
  geom_bar(alpha=0.7) +
  fhiplot::scale_fill_fhi(palette = "div_blue_red", direction = -1)


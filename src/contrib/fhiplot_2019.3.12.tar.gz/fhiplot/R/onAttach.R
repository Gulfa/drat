.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: org")
  packageStartupMessage("Version 2019.03.12 at 15:11")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

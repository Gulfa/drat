get_e_password <- function() {
  if (file.exists("/etc/gmailr/emayili.txt")) {
    con <- file("/etc/gmailr/emayili.txt", "r")
    password_gmail <- readLines(con, n = 1)
    close(con)
  } else {
    password_gmail <- "NO_NAME_FOUND"
  }
  config$password_gmail <- password_gmail
}

#' e_password
#' @export
e_password <- function() {
  if (config$password_gmail == "x") {
    get_e_password()
  }
  return(config$password_gmail)
}

#' smtp
#' @param msg a
#' @param verbose a
#' @export
smtp <- emayili::server(
  host = "smtp.gmail.com",
  port = 465,
  username = "dashboardsfhi@gmail.com",
  password = e_password()
)

#' e_subject
#' @param subject a
#' @export
e_subject <- function(subject) {
  if (!config$is_production) {
    subject <- glue::glue("TEST: {subject}")
  }
  return(subject)
}

#' e_footer
#' @export
e_footer <- function() {
  return(glue::glue("
    DO NOT REPLY TO THIS EMAIL! This email address is not checked by anyone!
    <br>
    To add or remove people to/from this notification list, send their details to richard.white@fhi.no
    "))
}

#' e_emails
#' @param project a
#' @export
e_emails <- function(project) {
  if (config$is_production) {
    emails <- readxl::read_excel("/etc/gmailr/emails.xlsx")
  } else {
    emails <- readxl::read_excel("/etc/gmailr/emails_test.xlsx")
  }

  emails <- stats::na.omit(emails[[project]])

  return(emails)
}

#' latin1_to_utf8
#' Takes a data.frame and converts it to utf8
#' @param df data.frame to convert
#' @export
latin1_to_utf8 <- function(df) {
  # setDT(df)
  dx <- data.table(df)
  for (i in names(dx)) {
    try(if ("UTF-8" %in% Encoding(dx[[i]])) dx[, (i) := iconv(get(i), from = "latin1", to = "utf8")], TRUE)
  }
  return(dx)
}

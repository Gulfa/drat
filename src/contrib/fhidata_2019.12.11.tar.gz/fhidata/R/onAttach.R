.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.12.11 at 18:20")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

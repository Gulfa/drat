.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2019.03.22 at 08:17")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

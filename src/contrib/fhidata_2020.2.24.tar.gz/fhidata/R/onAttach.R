.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2020.02.24 at 09:47")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

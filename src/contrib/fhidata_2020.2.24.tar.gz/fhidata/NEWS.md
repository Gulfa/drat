# fhidata 2020.2.24

- Included world map

# fhidata 2020.2.20

- Included county map for 2017 borders

# fhidata 2020.2.10

- Fixed duplicated population at national level
- level = nation, county, municip

# fhidata 2020.1.28

- Included maps with inserts for Oslo

# fhidata 2020.1.23

- Upgraded to 2020 borders
- Now most datasets end in either "_b2020" (2020 borders) or "_b2019" (2019 borders)

# fhidata 2019.8.27

- Including national population data from 1846 (instead of 2006)

# fhidata 2019.6.24

- Including childhood vaccination data.

# fhidata 2019.5.19

- Switching map files from UTM to lat/long coordinates.

# fhidata 2019.4.2

- Submission to CRAN.

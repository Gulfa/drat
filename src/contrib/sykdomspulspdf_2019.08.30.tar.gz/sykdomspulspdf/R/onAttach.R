.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: sykdomspulspdf")
  packageStartupMessage("Version 2019.08.30 at 06:28")
  packageStartupMessage("Developed by B Valcarcel")
  packageStartupMessage("Department of Infectious Disease Epidemiology and Modelling")
  packageStartupMessage("Norwegian Institute of Public Health")
}

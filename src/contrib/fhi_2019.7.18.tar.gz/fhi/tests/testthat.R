library(testthat)
library(fhi)

test_check("fhi")

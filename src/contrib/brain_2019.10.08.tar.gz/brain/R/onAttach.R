.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2019.10.08 at 06:43")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.11.28 at 07:13")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

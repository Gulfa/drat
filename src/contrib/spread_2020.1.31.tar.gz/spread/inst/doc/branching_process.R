## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----message=FALSE, warning=FALSE, fig.height=5, fig.width=7------------------
library(ggplot2)
library(epitrix)

#Defining the serial interval

mu <- 8.4
sd <- 3.4
param <- epitrix::gamma_mucv2shapescale(mu, sd/mu)
si <-   distcrete::distcrete("gamma", interval = 1,
                shape = param$shape,
                scale = param$scale, w = 0)


incidences <- spread::branching_process(initial_cases=1,                
                         R0=1.4,
                         dispersion=1,
                         serial_interval=si,
                         end_time=30,
                         N=1000)
summary <- spread::summarize_bp(incidences)
spread::plot_quantiles(incidences) + ggtitle("Estimated daily incidence") + xlab("Days") + ylab("Incidence")
spread::plot_quantiles(summary$cummulative) + ggtitle("Estimated cummulative case counts")  + xlab("Days") + ylab("Cummulative Cases")

ggplot() + geom_histogram(aes(x=colSums(incidences))) +theme_minimal() +ggtitle("Distribution of number of cases after 30 days") + xlab("N cases after 30 days") 

print(median(summary$cummulative[30,]))
print(summary$p_no_spread)


## -----------------------------------------------------------------------------
mu <- 8.4
sd <- 3.4
param <- epitrix::gamma_mucv2shapescale(mu, sd/mu)
si <-   distcrete::distcrete("gamma", interval = 1,
                shape = param$shape,
                scale = param$scale, w = 0)
params <- list()
for(R0 in seq(from=1, to=10, by=0.05)){
    params[[length(params)+1]] <- list(
      initial_cases=1,                
      R0=R0,
      dispersion=1,
      serial_interval=si,
      end_time=56
    )
}

r <- spread::fit_params_bp(2000,3000, params, N=1000)
print(HDInterval::hdi(r$R0))


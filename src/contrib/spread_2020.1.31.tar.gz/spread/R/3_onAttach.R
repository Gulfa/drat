.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: spread")
  packageStartupMessage("Version: 2020.01.31 at 11:07")
  packageStartupMessage("Commuter model and C++ code developed by Solveig Engebretsen and Andreas Nyg\u00E5rd Osnes")
  packageStartupMessage("Commuter ported to RCPP by Richard White")
  packageStartupMessage("Branching process developed by Gunnar Ro")
}

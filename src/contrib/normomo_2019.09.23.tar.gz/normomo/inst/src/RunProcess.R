fhi::DashboardInitialiseOpinionated("normomo", PACKAGE_DIR=".")
fd::initialize("normomo")
suppressMessages(library(data.table))
suppressMessages(library(ggplot2))

info <- GetDataInfo()

masterData <- GetData(
  fDone=info[["fDone"]],
  f=info[["f"]],
  forceRun=fd::config$is_dev
  )

# Set up folders
SetupFolders(dateDataMinusOneWeek=info[["dateDataMinusOneWeek"]])

# standard
model <- standard$new()
results_x <- model$results_x
model$run_all(masterData=masterData, info=info)

# daily
model <- daily$new()
model$run_all(masterData=masterData)

CreateLatestDoneFile(f=info$f)

x <- fd::tbl("normomo_standard_results") %>% dplyr::collect() %>% fd::latin1_to_utf8()
date_results <- max(x$date)

fd::update_rundate(
  package="normomo",
  date_extraction = info$dateData,
  date_results = date_results,
  date_run = lubridate::today()
  )


fd::msg("Exited successfully", slack = T)
if(!fd::config$is_dev) quit(save="no", status=0)

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2019.09.23 at 05:10")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(ggplot2)
library(data.table)
library(fhiplot)

## ------------------------------------------------------------------------
set.seed(4)
dates <- sample(seq.Date(as.Date("2018-01-01"), 
                         as.Date("2018-02-08"), 1),
                20000, 
                replace = T)
d <- expand.grid(
  location_code=unique(fhidata::norway_locations_current$county_code),
  date = dates
)
# Convert to data.table
setDT(d)

# print
print(d)

## ------------------------------------------------------------------------
# Convert to data.table
setDT(d)

# aggregate
d <- d[,
  .(
    N = .N
  ),
  keyby = .(
    location_code,
    date
  )
]
# aggregated daily dataset that does not contain days with 0 cases
print(d)

# create skeleton
skeleton <- data.table(expand.grid(
  location_code = unique(fhidata::norway_locations_current$county_code),
  date = seq.Date(min(d$date), max(d$date), 1)
))

# merge the two datasets together
d <- merge(d, skeleton, by=c("location_code", "date"), all=T)

# Fill in 'missing' Ns with 0
d[is.na(N), N := 0]

# Now you have a clean aggregated daily dataset that contains days with 0 cases!
print(d)

## ------------------------------------------------------------------------
# create 3 new variables:
d[, isoyearweek := fhi::isoyearweek(date)]

# aggregate down to weekly level
w <- d[,
  .(
    N = sum(N)
  ),
  keyby = .(
    location_code,
    isoyearweek
  )
]
print(w)

## ------------------------------------------------------------------------
p <- ggplot(d[location_code=="county01"], aes(x = date, y = N))
p <- p + geom_col(fill = fhiplot::base_color, width = 0.8)
p <- p + scale_x_date("Date")
p <- p + scale_y_continuous("Number of reported cases",
  breaks = fhiplot::pretty_breaks(5),
  expand = expand_scale(mult = c(0, 0.1))
)
p <- p + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
p <- p + labs(caption = "Data extracted on 2018-02-20")
p <- p + fhiplot::theme_fhi_lines()
p

## ------------------------------------------------------------------------
p <- ggplot(w[location_code=="county01"], aes(x = isoyearweek, y = N))
p <- p + geom_col(fill = fhiplot::base_color, width = 0.8)
p <- p + scale_x_discrete("Isoweek")
p <- p + scale_y_continuous("Number of reported cases",
  breaks = fhiplot::pretty_breaks(5),
  expand = expand_scale(mult = c(0, 0.1))
)
p <- p + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
p <- p + labs(caption = "Data extracted on 2018-02-20")
p <- p + fhiplot::theme_fhi_lines()
p

## ------------------------------------------------------------------------
p <- ggplot(w, aes(x = isoyearweek, y = N))
p <- p + geom_col(fill = fhiplot::base_color, width = 0.8)
p <- p + scale_x_discrete("Isoweek")
p <- p + scale_y_continuous("Number of reported cases",
  breaks = fhiplot::pretty_breaks(5),
  expand = expand_scale(mult = c(0, 0.1))
)
p <- p + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
p <- p + labs(caption = "Data extracted on 2018-02-20")
p <- p + fhiplot::theme_fhi_lines()
p <- p + fhiplot::set_x_axis_vertical()
p

## ----fig.height=10, fig.width=8------------------------------------------
p <- ggplot(d, aes(x = date, y = N))
p <- p + geom_col(fill = fhiplot::base_color, width = 0.8)
p <- p + lemon::facet_rep_wrap(~location_code, repeat.tick.labels = "y")
p <- p + fhiplot::scale_fill_fhi("Location",palette="primary")
p <- p + scale_x_date("Date")
p <- p + scale_y_continuous("Number of reported cases",
  breaks = fhiplot::pretty_breaks(5),
  expand = expand_scale(mult = c(0, 0.1))
)
p <- p + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
p <- p + labs(caption = "Data extracted on 2018-02-20")
p <- p + fhiplot::theme_fhi_lines()
p <- p + fhiplot::set_x_axis_vertical()
p

## ----fig.height=10, fig.width=8------------------------------------------
p <- ggplot(d, aes(x = isoyearweek, y = N))
p <- p + geom_col(fill = fhiplot::base_color, width = 0.8)
p <- p + lemon::facet_rep_wrap(~location_code, repeat.tick.labels = "y", ncol=4)
p <- p + scale_fill_fhi("Location",palette="primary")
p <- p + scale_x_discrete("Isoweek")
p <- p + scale_y_continuous("Number of reported cases",
  breaks = fhiplot::pretty_breaks(5),
  expand = expand_scale(mult = c(0, 0.1))
)
p <- p + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
p <- p + labs(caption = "Data extracted on 2018-02-20")
p <- p + theme_fhi_lines()
p <- p + fhiplot::set_x_axis_vertical()
p

## ------------------------------------------------------------------------
p <- ggplot(w[location_code %in% c(
  "county01",
  "county02",
  "county03",
  "county04",
  "county05")], 
  aes(x = isoyearweek, y = N, fill = location_code))
p <- p + geom_col(width = 0.8)
p <- p + fhiplot::scale_fill_fhi("Location",palette="primary")
p <- p + scale_x_discrete("Isoweek")
p <- p + scale_y_continuous("Number of reported cases",
  breaks = fhiplot::pretty_breaks(5),
  expand = expand_scale(mult = c(0, 0.1))
)
p <- p + labs(title = "Epicurve from 2018-01-01 to 2018-02-20")
p <- p + labs(caption = "Data extracted on 2018-02-20")
p <- p + fhiplot::theme_fhi_lines()
p <- p + fhiplot::set_x_axis_vertical()
p


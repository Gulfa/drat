.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.08.31 at 16:59")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

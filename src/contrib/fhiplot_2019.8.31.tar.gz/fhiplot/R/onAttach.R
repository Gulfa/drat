.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.08.31 at 17:19")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

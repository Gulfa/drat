.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: normomo")
  packageStartupMessage("Version 2018.11.21 at 13:47")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2019.12.09 at 10:04")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2019.09.26 at 10:20")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

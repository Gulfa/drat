.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: plnr")
  packageStartupMessage("Version 2020.01.24 at 20:40")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

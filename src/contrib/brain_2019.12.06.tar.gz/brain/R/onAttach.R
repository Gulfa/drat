.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: brain")
  packageStartupMessage("Version 2019.12.06 at 20:29")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

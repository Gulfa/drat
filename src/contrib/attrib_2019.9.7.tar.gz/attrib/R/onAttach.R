.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.09.07 at 20:05")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhidata")
  packageStartupMessage("Version: 2019.07.29 at 05:03")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}

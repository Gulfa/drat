## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
for(i in names(fhi::PROJ)){
  print(sprintf("%s=%s",i,fhi::PROJ[[i]]))
}

## ------------------------------------------------------------------------
# Create an empty package
pkg <- file.path(tempdir(check=TRUE),"ANALYSIS")
devtools::create(pkg,quiet=F)

# Create the data/results/src folders
tmpdir <- tempdir(check=TRUE)
dir.create(file.path(tmpdir,"data_raw"))
dir.create(file.path(tmpdir,"data_clean"))
dir.create(file.path(tmpdir,"data_app"))
dir.create(file.path(tmpdir,"results"))
dir.create(file.path(tmpdir,"src"))

# Create the `ANALYSIS` specific folders inside
dir.create(file.path(tmpdir,"data_raw","ANALYSIS"))
dir.create(file.path(tmpdir,"data_clean","ANALYSIS"))
dir.create(file.path(tmpdir,"data_app","ANALYSIS"))
dir.create(file.path(tmpdir,"results","ANALYSIS"))
dir.create(file.path(tmpdir,"src","ANALYSIS"))

# Initialise
fhi::DashboardInitialiseOpinionated("ANALYSIS",STUB=tmpdir, PACKAGE_DIR=pkg, FORCE_DEV_PACKAGE_LOAD=TRUE)

# Lets see how `fhi::PROJ` has changed:
for(i in names(fhi::PROJ)){
  print(sprintf("%s=%s",i,fhi::PROJ[[i]]))
}


library(testthat)
library(spulsconnect)

test_check("spulsconnect")

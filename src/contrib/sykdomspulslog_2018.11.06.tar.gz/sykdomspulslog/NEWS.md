# sykdomspuls_log 2018.10.25

## Migration

Migrating from [raubreywhite/dashboards_sykdomspuls_log](https://www.github.com/raubreywhite/dashboards_sykdomspuls_log/) to [folkehelseinstituttet/dashboards_sykdomspuls_log](https://www.github.com/folkehelseinstituttet/dashboards_sykdomspuls_log/)
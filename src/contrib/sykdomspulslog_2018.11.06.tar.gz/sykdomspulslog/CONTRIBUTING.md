## Development guidelines

Please refer to the [umbrella Dashboards project for guidelines](https://folkehelseinstituttet.github.io/dashboards/contributing.html).


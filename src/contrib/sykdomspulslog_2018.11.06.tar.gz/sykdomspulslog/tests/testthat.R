library(testthat)
library(sykdomspulslog)

test_check("sykdomspulslog")

## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(spread)

## -----------------------------------------------------------------------------
spread::asymmetric_mobility_dummy_seiiar_pop

## -----------------------------------------------------------------------------
length(spread::asymmetric_mobility_dummy_mobility_matrix)
spread::asymmetric_mobility_dummy_mobility_matrix[[1]]

## -----------------------------------------------------------------------------
spread::asymmetric_mobility_dummy_betas

## -----------------------------------------------------------------------------
d <- spread::asymmetric_mobility(
  seiiar_pop = spread::asymmetric_mobility_dummy_seiiar_pop,
  mobility_matrix = spread::asymmetric_mobility_dummy_mobility_matrix,
  betas = spread::asymmetric_mobility_dummy_betas,
  latent_period = 1.9,
  infectious_period = 3.0,
  asymptomatic_prob = 0,
  asymptomatic_relative_infectiousness = 0,
  N = 1
)

## -----------------------------------------------------------------------------
print(d)


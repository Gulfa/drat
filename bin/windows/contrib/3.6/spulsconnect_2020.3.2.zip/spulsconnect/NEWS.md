# spulsconnect 2020.2.28

- Initial release of norsyss_download_diagnoses

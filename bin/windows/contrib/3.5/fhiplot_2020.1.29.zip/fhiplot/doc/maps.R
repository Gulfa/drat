## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
# start off with base map
pd <- fhidata::norway_map_counties_b2020

# create some fictional data
data <- unique(pd[,c("location_code")])
suppressWarnings(data[,category:=rep(c("Good","Normal","Neutral","Bad","Very Bad"),each=4)[1:.N]])
data[,category_with_missing:=category]
data[1,category_with_missing:="Missing"]
data[,category:=factor(category,levels=c("Good","Normal","Neutral","Bad","Very Bad"))]
data[,category_with_missing:=factor(category_with_missing,levels=c("Good","Normal","Neutral","Bad","Very Bad","Missing"))]
data[location_code == "county54", category:='Very Bad']
data[location_code == "county54", category_with_missing:='Very Bad']

# merge the data into the map
pd[data,on="location_code",category:=category]
pd[data,on="location_code",category_with_missing:=category_with_missing]

## ----fig.height=7, fig.width=7------------------------------------------------
library(ggplot2)
library(fhiplot)

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=category), color="black")
q <- q + theme_void()
q <- q + coord_quickmap()
q <- q + fhiplot::scale_fill_fhi("Category",palette = "map_div_complete", direction = 1, drop=F)
q <- q + labs(title = "Norwegian counties with 2020 borders")
q

## ----fig.height=7, fig.width=7------------------------------------------------
library(ggplot2)
library(fhiplot)

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=category_with_missing), color="black")
q <- q + theme_void()
q <- q + coord_quickmap()
q <- q + fhiplot::scale_fill_fhi("Category",palette = "map_div_missing", direction = 1, drop=F)
q <- q + labs(title = "Norwegian counties with 2020 borders")
q

## -----------------------------------------------------------------------------
# start off with base map
pd <- fhidata::norway_map_counties_with_insert_b2020

# create some fictional data
data <- unique(pd[,c("location_code")])
suppressWarnings(data[,category:=rep(c("Good","Normal","Neutral","Bad","Very Bad"),each=4)[1:.N]])
data[,category_with_missing:=category]
data[1,category_with_missing:="Missing"]
data[,category:=factor(category,levels=c("Good","Normal","Neutral","Bad","Very Bad"))]
data[,category_with_missing:=factor(category_with_missing,levels=c("Good","Normal","Neutral","Bad","Very Bad","Missing"))]
data[location_code == "county54", category:='Very Bad']
data[location_code == "county54", category_with_missing:='Very Bad']

# merge the data into the map
pd[data,on="location_code",category:=category]
pd[data,on="location_code",category_with_missing:=category_with_missing]

## ----fig.height=7, fig.width=7------------------------------------------------
library(ggplot2)
library(fhiplot)

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=category), color="black")
q <- q + annotate(
  "text", 
  x = fhidata::norway_map_insert_title_position_b2020$long, 
  y = fhidata::norway_map_insert_title_position_b2020$lat,
  label = "Oslo"
  )
q <- q + theme_void()
q <- q + coord_quickmap()
q <- q + fhiplot::scale_fill_fhi("Category",palette = "map_div_complete", direction = 1, drop=F)
q <- q + labs(title = "Norwegian counties with 2020 borders")
q

## ----fig.height=7, fig.width=7------------------------------------------------
library(ggplot2)
library(fhiplot)

q <- ggplot()
q <- q + geom_polygon(data = pd, aes( x = long, y = lat, group = group, fill=category_with_missing), color="black")
q <- q + annotate(
  "text", 
  x = fhidata::norway_map_insert_title_position_b2020$long, 
  y = fhidata::norway_map_insert_title_position_b2020$lat,
  label = "Oslo"
  )
q <- q + theme_void()
q <- q + coord_quickmap()
q <- q + fhiplot::scale_fill_fhi("Category",palette = "map_div_missing", direction = 1, drop=F)
q <- q + labs(title = "Norwegian counties with 2020 borders")
q


# plnr 2020.1.28

- parallel_possible variable when initializing new Plan

# spulsconnect 2020.3.6

Including new functions:

- norsyss_connect
- norsyss_download_raw

Including vignette:

- norsyss_data

# spulsconnect 2020.2.28

- Initial release of norsyss_download_diagnoses
